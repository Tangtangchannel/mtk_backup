default_ids = [
    [0x0E8D, 0x0003, -1], # MTK Brom
    [0x0E8D, 0x6000, 2], # MTK Preloader
    [0x0E8D, 0x2000, -1], # MTK Preloader
    [0x0E8D, 0x2001, -1], # MTK Preloader
    [0x0E8D, 0x20FF, -1], # MTK Preloader
    [0x1004, 0x6000, 2], # LG Preloader
    [0x22d9, 0x0006, -1], # OPPO Preloader
    [0x0FCE, 0xF200, -1], # Sony Brom
]
