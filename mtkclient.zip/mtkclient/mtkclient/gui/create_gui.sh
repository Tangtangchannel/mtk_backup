#!/bin/sh
pyside6-uic main_gui.ui -o main_gui.py
