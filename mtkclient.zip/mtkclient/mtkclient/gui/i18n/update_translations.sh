#!/bin/sh
pyside6-lupdate ../*.py ../../../mtkclient/Library/*.py ../../../mtk_gui ../*.ui -ts *.ts
